#include<iostream>
using namespace std;
int main()
{
		freopen("sum.in", "r", stdin);
		freopen("sum.out", "w", stdout);

	int n;
	int cmp = 0;
	int s, k;
	cin >> k >> s;
	for (int i = 0; i <= 3; i++)
	{
		for (int j = 0; j <= 2; j++)
		{
			for (int k = 0; k <= 1; k++)
			{
				if (i + j + k == s)
				{

					cmp++;
				}
			}
		}
	}
	cout << cmp + 1;
	return 0;
}