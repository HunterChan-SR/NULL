#include<bits/stdc++.h>
using namespace std;
int s,k,cmp;
int main()
{
//	freopen("sum.in","r",stdin);
//	freopen("sum.out","w",stdout); 
	cin>>k>>s;
	for(int i=0;i<=3;i++)
	{
		for(int j=0;j<=2;j++)
		{
			for(int k=0;k<=1;k++)
			{
				if(i+j+k==s)
				{
					cmp++;
				}
			}
		}
	} 
	cout<<cmp+1;
	return 0;
} 
