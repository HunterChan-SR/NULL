#include<bits/stdc++.h>
using namespace std;
int a,b,c,d,e; 
int main()
{
//	freopen("christmas.in","r",stdin);
//	freopen("christmas.out","w",stdout);
	cin>>a>>b>>c>>d;
	if(a<c || a>d)
	{
		cout<<0;
		return 0;
	}
	e=(a-c)/b+(d-a)/b+1;
	printf("%d",e); 
	return 0;
} 
